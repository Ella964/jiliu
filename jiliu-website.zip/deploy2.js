const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'index.html');
const content = fs.readFileSync(filePath, 'utf8');
const fileName = 'index.html';
const fileBuffer = Buffer.from(content, 'utf8');

console.log(`File size: ${fileBuffer.length} bytes`);

// Try multiple IPFS upload endpoints
const uploadTargets = [
  { host: 'ipfs.infura.io', port: 5001, path: '/api/v0/add', protocol: 'http', name: 'Infura Local' },
  { host: 'node1.hk.api.nf.io', port: 443, path: '/ipfs/api/v0/add?pin=true', protocol: 'https', name: 'NFT.Storage' },
];

async function tryUpload(target) {
  return new Promise((resolve) => {
    const https = require('https');
    const http = require('http');
    const lib = protocol === 'https' ? https : http;
    
    console.log(`Trying ${target.name} (${target.host}${target.path})...`);
    
    const boundary = '----WebKitFormBoundary' + Date.now().toString(36);
    const body = Buffer.concat([
      Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${fileName}"\r\nContent-Type: text/html\r\n\r\n`),
      fileBuffer,
      Buffer.from(`\r\n--${boundary}--\r\n`)
    ]);
    
    const req = lib.request({
      hostname: target.host,
      port: target.port,
      path: target.path,
      method: 'POST',
      headers: {
        'Content-Type': `multipart/form-data; boundary=${boundary}`,
        'Content-Length': body.length
      },
      timeout: 20000
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        console.log(`  Status: ${res.statusCode}`);
        console.log(`  Response: ${data.substring(0, 200)}`);
        if (res.statusCode === 200) {
          try {
            const result = JSON.parse(data);
            console.log(`  ✅ CID: ${result.Hash}`);
            resolve(result.Hash);
          } catch(e) { console.log('  Parse error'); resolve(null); }
        } else { resolve(null); }
      });
    });
    
    req.on('error', err => {
      console.log(`  Error: ${err.message}`);
      resolve(null);
    });
    
    req.setTimeout(20000, () => {
      console.log('  Timeout');
      req.destroy();
      resolve(null);
    });
    
    req.write(body);
    req.end();
  });
}

async function main() {
  for (const target of uploadTargets) {
    const cid = await tryUpload(target);
    if (cid) {
      console.log(`\n✅ SUCCESS! CID: ${cid}`);
      console.log(`Gateway: https://ipfs.io/ipfs/${cid}`);
      console.log(`Cloudflare: https://cloudflare-ipfs.com/ipfs/${cid}`);
      return;
    }
  }
  console.log('\nAll cloud uploads failed.');
  console.log('File is ready locally at:', filePath);
  console.log('\nTo deploy with pinme:');
  console.log('  1. Run: pinme login (requires MetaMask wallet)');
  console.log('  2. Run: pinme upload ./jiliu-website');
}

main();
