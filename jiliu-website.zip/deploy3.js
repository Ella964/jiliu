const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');

const filePath = path.join(__dirname, 'index.html');
const content = fs.readFileSync(filePath, 'utf8');
const fileName = 'index.html';
const fileBuffer = Buffer.from(content, 'utf8');

console.log(`File size: ${fileBuffer.length} bytes`);
console.log('');

// Try uploading to Cloudflare IPFS via HTTP (not HTTPS)
function uploadToCloudflare() {
  return new Promise((resolve) => {
    console.log('Trying Cloudflare IPFS gateway...');
    
    const boundary = '----Boundary' + Date.now().toString(36);
    const body = Buffer.concat([
      Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${fileName}"\r\nContent-Type: text/html\r\n\r\n`),
      fileBuffer,
      Buffer.from(`\r\n--${boundary}--\r\n`)
    ]);
    
    const req = http.request({
      hostname: 'cloudflare-ipfs.com',
      port: 80,
      path: '/ipfs/api/v0/add?pin=true',
      method: 'POST',
      headers: {
        'Content-Type': `multipart/form-data; boundary=${boundary}`,
        'Content-Length': body.length
      },
      timeout: 15000
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        console.log(`  Status: ${res.statusCode}`);
        console.log(`  Body: ${data.substring(0, 300)}`);
        if (res.statusCode === 200) {
          try {
            const result = JSON.parse(data);
            console.log(`  CID: ${result.Hash}`);
            resolve(result.Hash);
          } catch(e) { resolve(null); }
        } else { resolve(null); }
      });
    });
    
    req.on('error', err => {
      console.log(`  HTTP error: ${err.message}`);
      resolve(null);
    });
    
    req.setTimeout(15000, () => {
      console.log('  Timeout');
      req.destroy();
      resolve(null);
    });
    
    req.write(body);
    req.end();
  });
}

// Try Infura IPFS
function uploadToInfura() {
  return new Promise((resolve) => {
    console.log('\nTrying Infura IPFS...');
    
    const boundary = '----Boundary' + Date.now().toString(36);
    const body = Buffer.concat([
      Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${fileName}"\r\nContent-Type: text/html\r\n\r\n`),
      fileBuffer,
      Buffer.from(`\r\n--${boundary}--\r\n`)
    ]);
    
    const req = http.request({
      hostname: 'ipfs.infura.io',
      port: 5001,
      path: '/api/v0/add',
      method: 'POST',
      headers: {
        'Content-Type': `multipart/form-data; boundary=${boundary}`,
        'Content-Length': body.length
      },
      timeout: 15000
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        console.log(`  Status: ${res.statusCode}`);
        console.log(`  Body: ${data.substring(0, 300)}`);
        if (res.statusCode === 200) {
          try {
            const result = JSON.parse(data);
            console.log(`  CID: ${result.Hash}`);
            resolve(result.Hash);
          } catch(e) { resolve(null); }
        } else { resolve(null); }
      });
    });
    
    req.on('error', err => {
      console.log(`  Error: ${err.message}`);
      resolve(null);
    });
    
    req.setTimeout(15000, () => {
      console.log('  Timeout');
      req.destroy();
      resolve(null);
    });
    
    req.write(body);
    req.end();
  });
}

async function main() {
  const cid1 = await uploadToCloudflare();
  if (cid1) {
    console.log('\n✅ SUCCESS!');
    console.log(`CID: ${cid1}`);
    console.log(`https://cloudflare-ipfs.com/ipfs/${cid1}`);
    console.log(`https://ipfs.io/ipfs/${cid1}`);
    return;
  }
  
  const cid2 = await uploadToInfura();
  if (cid2) {
    console.log('\n✅ SUCCESS!');
    console.log(`CID: ${cid2}`);
    console.log(`https://ipfs.io/ipfs/${cid2}`);
    return;
  }
  
  console.log('\n❌ All uploads failed.');
  console.log('\nFile is ready locally at:');
  console.log(filePath);
  console.log('\nTo deploy with pinme CLI:');
  console.log('  1. Open browser and go to https://pinme.eth.limo');
  console.log('  2. Click "登录" to authenticate with MetaMask wallet');
  console.log('  3. Then run: pinme upload ./jiliu-website');
}

main();
