const fs = require('fs');
const path = require('path');
const https = require('https');

const filePath = path.join(__dirname, 'index.html');
const content = fs.readFileSync(filePath, 'utf8');
const fileName = 'index.html';
const fileBuffer = Buffer.from(content, 'utf8');

console.log(`File size: ${fileBuffer.length} bytes`);
console.log('Uploading to IPFS via Cloudflare...');

// Upload to Cloudflare IPFS gateway
const boundary = '----WebKitFormBoundary' + Date.now().toString(36);
const body = Buffer.concat([
  Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${fileName}"\r\nContent-Type: text/html\r\n\r\n`),
  fileBuffer,
  Buffer.from(`\r\n--${boundary}--\r\n`)
]);

const req = https.request({
  hostname: 'cloudflare-ipfs.com',
  port: 443,
  path: '/ipfs/api/v0/add?pin=true',
  method: 'POST',
  headers: {
    'Content-Type': `multipart/form-data; boundary=${boundary}`,
    'Content-Length': body.length
  },
  timeout: 30000
}, (res) => {
  let data = '';
  res.on('data', chunk => data += chunk);
  res.on('end', () => {
    try {
      const result = JSON.parse(data);
      console.log('Success! CID:', result.Hash);
      console.log('Gateway URL: https://cloudflare-ipfs.com/ipfs/' + result.Hash);
      console.log('ENS URL: https://' + result.Hash + '.eth.limo');
    } catch (e) {
      console.log('Response:', data.substring(0, 500));
      console.log('Trying alternative method...');
      
      // Try textise approach
      console.log('File ready at: D:\\nxnos_4417\\resources\\nxnos\\platform\\agents\\main\\jiliu-website\\index.html');
      console.log('You can upload manually using: pinme upload ./jiliu-website');
    }
  });
});

req.on('error', (err) => {
  console.log('Cloudflare IPFS error:', err.message);
  console.log('File is ready locally at:', filePath);
  console.log('Manual deployment: pinme upload ./jiliu-website (requires wallet login)');
});

req.setTimeout(30000, () => {
  console.log('Request timeout');
  req.destroy();
});

req.write(body);
req.end();
